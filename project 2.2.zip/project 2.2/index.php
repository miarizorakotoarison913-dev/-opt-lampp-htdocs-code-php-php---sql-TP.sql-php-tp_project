<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <header>
    <header>
    <div class="section text-center bg-warning py-3 shadow-sm">

    <h1>--BIENVENUE--</h1>
    </div>
    </header>
    </header>
    <main>
        <br>
        <br>
        <br>
        <div class="text-center">
            <h2>----Choix----</h2>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <hr>
        <p class="text-center">Voir<a href="page/liste.php" class="text-decoration-none text-info fw-semibold">liste des departement</a></p>
        <p class="text-center">Voir<a href="page/liste_nb_employees.php" class="text-decoration-none text-info fw-semibold">nb employees homme et femme</a></p>
            
        <hr>

    </main>





</body>

</html>