<?php
include( 'function/connect.php');
function get_all_lines($sql){
    $req = mysqli_query(dbconnect(),$sql );
    $result = array();
    while ($line = mysqli_fetch_assoc($req)) {
        $result[] = $line;
    }
    mysqli_free_result($req);
    return $result;
}

function get_one_line($sql){
    $req = mysqli_query(dbconnect(),$sql );
    $result = mysqli_fetch_assoc($req);
    mysqli_free_result($req);
    return $result;
}

function get_dep(){
    $sql = " select dept_no,dept_name from departments";
    return get_all_lines($sql); 
}

// manager responsable de chaque departement
function get_manager(){
    $sql= "select  departments.dept_no,departments.dept_name,employees.first_name,nb_employees from dept_manager join departments on dept_manager.dept_no=departments.dept_no join employees on dept_manager.emp_no = employees.emp_no join V_nbemployees on dept_manager.dept_no = V_nbemployees.dept_no where dept_manager.to_date > CURDATE()";
    return get_all_lines($sql); 
}

// departement - employer
function get_dep_employees($id){
    $sql = "SELECT * FROM dept_emp WHERE dept_no = '%s'";
    $sql = sprintf($sql, $id);
    $req = mysqli_query(dbconnect(),$sql);
    $result = array();
    while ($line = mysqli_fetch_assoc($req)) {
        $result[] = $line;
    }
    mysqli_free_result($req);
    return $result;
    
    }
    
// SELECT * FROM dept_emp  JOIN employees ON employees.emp_no = dept_emp.emp_no WHERE dept_no = '%s'  


function look_employees($id){
    $sql = " SELECT first_name,to_date,from_date,employees.emp_no  as num_emp FROM dept_emp  JOIN employees ON employees.emp_no = dept_emp.emp_no WHERE employees.emp_no = $id " ;
    return get_all_lines($sql);

}

function look($emp_name,$dep_name,$age_min,$age_max){
    $sql="";
    return get_all_lines($sql);

}





// fiche pour les employers
function get_employees($id){
    $sql = "SELECT * FROM employees WHERE emp_no = '%s'";
    $sql = sprintf($sql, $id);
    $req = mysqli_query(dbconnect(),$sql);
    $result = array();
    while ($line = mysqli_fetch_assoc($req)) {
        $result[] = $line;
    }
    mysqli_free_result($req);
    return $result;

}   

// fonction pour voir l historique des salaire 
function get_salaries($id){
    $sql = "SELECT * FROM salaries WHERE emp_no = '%s'"; // (pour un employee en particulier)
    $sql = sprintf($sql, $id);
    $req = mysqli_query(dbconnect(),$sql);
    $result = array();
    while ($line = mysqli_fetch_assoc($req)) {
        $result[] = $line;
    }
    mysqli_free_result($req);
    return $result;

}   

function get_men_women(){
    $sql ="select avg(salary) as moyenne_salaire, count(first_name) as nb_homme_femme ,gender from employees  join salaries on employees.emp_no = salaries.emp_no  group by gender";
    return get_all_lines($sql);
}
//select count(first_name) as nb_homme_femme ,gender from employees group by gender
// select avg(salary) as moyenne_salaire, count(first_name) as nb_homme_femme ,gender from employees  join salaries on employees.emp_no = salaries.emp_no  group by gender













































?>