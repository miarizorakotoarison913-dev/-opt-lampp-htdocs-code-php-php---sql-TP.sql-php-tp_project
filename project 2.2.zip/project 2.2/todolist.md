# 1 Object :

- page liste : liste de departement (ok)
- ajout colonne (manager en cour)
- lien sur chaque departement ---> liste des employer dans se departement

# 2 Tache


## Version 1

> Etape 1 : OK

- index (ok)
    - affichage
        - html
        - bootstarp
    - code
        - boutton verws la liste.prp   

- liste.php (ok)
    - affichage 
        - html
        - bootstarp
    - code dyanmique
    - function

- fonction.php 
    - fonction a utiliser
        - requperation de l sql
        - get manager

- connect.php (ok)
    - fonction de connextion (vers "employees")

> Etape 2  : OK

- Ajout (ok)
    - colonne du manager en cour
    - fonctionne special manager
    - code dynamique

> Etape 3 : Ok

- liste_employer (dans departement) (ok)
    - affichage
        - html
        - bootstarp
    - code dynamique
        - lien unificatrice
        - tableau avec liste des employer
    - function


## Version 2

>Etape 1.1 : OK

- fiche_employees.php (fiche de chacun des employees) (ok)
    - affichage (ok)
        - html
            - html de base
            - debut integration de structure
        - bootstarp leger
    - code dyamique (ok)
        - tableau d info
        - lien et connexion vers cette page
    - function (ok)
        - sql dynamique (special fiche)


> Etape 2.2 : OK

- historique.php (ok)
    - affichage (ok)
        - html
            - html de base
            - debut integration de structur 
    - code dynamique (ok)
        - lien vers la page 
        - historique propre pour chaque employees 
    - fuction (ok)
        - historique / salaire


> Etape 3.3 : OK 

-  Recherche (ok)
    - affichage 
        - html
            - form de recherche
    - code dynamique 
        - traitement des recherches 
    - function de recherche

- traitement.php
    - traiter les info de recherche
    - comparaison des donnees 
    - code dynamique


## Version 3

> Eatpe 1.1.1 : OK

- Ajout colonne nb d employees (ok)
    - affichage 
        - html :  ajout de colonne 
        - bootstrap
    - function 
        - modification du sql
        - modification de la fonction
    - code dynamique
        - sycronisation

> Etape 2.2.2 : OK

- Salaire_employees.php
    - affichage
        - html
        - boostrap
    - function
        - fonction special (grouper selon le genre)
    - code dynamique
        - triage selon le genre (homme/femme)
        - ajout de la moyenne du salaire
  



























